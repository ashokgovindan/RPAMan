package rpa.rpaman;

import com.github.lgooddatepicker.components.DatePicker;
import com.github.lgooddatepicker.components.DatePickerSettings;

import javax.swing.*;
import javax.swing.border.AbstractBorder;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellRenderer;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;
import java.lang.ref.WeakReference;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Small builders that give every screen the same look: rounded cards,
 * accent-coloured headers, pill buttons and theme-aware date pickers.
 */
public final class UiFactory {

    public static final int GAP = 12;

    /** Vertical space between a pane's title and the row under it. */
    public static final int HEADER_GAP = 8;

    private static int cachedHeaderHeight = -1;

    // Weak so short-lived windows (the settings dialog) can be collected
    private static final List<WeakReference<DatePicker>> DATE_PICKERS = new ArrayList<>();
    private static final List<WeakReference<JButton>> PRIMARY_BUTTONS = new ArrayList<>();

    static {
        ThemeManager.onThemeChanged(UiFactory::refreshRegisteredComponents);
    }

    private UiFactory() {
    }

    // ------------------------------------------------------------- headings

    /** Bold, accent-coloured section heading with a leading icon. */
    public static JLabel sectionTitle(String text, Icon icon) {
        JLabel label = new JLabel(text, icon, SwingConstants.LEADING);
        label.setIconTextGap(8);
        label.setFont(label.getFont().deriveFont(Font.BOLD, 15f));
        ThemeManager.styleOnThemeChange(label, l -> l.setForeground(ThemeManager.accent()));
        return label;
    }

    /** Muted secondary line used under section titles. */
    public static JLabel subtitle(String text) {
        JLabel label = new JLabel(text);
        label.setFont(label.getFont().deriveFont(Font.PLAIN, 12f));
        ThemeManager.styleOnThemeChange(label, l -> l.setForeground(ThemeManager.subtle()));
        return label;
    }

    /** Small bold label used for form field captions. */
    public static JLabel fieldLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(label.getFont().deriveFont(Font.BOLD, 12f));
        ThemeManager.styleOnThemeChange(label, l -> l.setForeground(ThemeManager.accent()));
        return label;
    }

    /**
     * Fixed-height heading block: a title with an optional second row beneath.
     * <p>
     * Every pane uses one of these so the tree, the details card and the tasks
     * table all start on the same line, no matter what the second row holds.
     */
    public static JPanel headerBlock(JLabel title, JComponent secondRow) {
        JPanel panel = transparent(new BorderLayout(0, HEADER_GAP));
        panel.add(title, BorderLayout.NORTH);

        if (secondRow != null) {
            // NORTH inside the holder keeps the row at its natural height and
            // pushes any leftover slack below it, instead of stretching it.
            JPanel holder = transparent(new BorderLayout());
            holder.add(secondRow, BorderLayout.NORTH);
            panel.add(holder, BorderLayout.CENTER);
        }

        int height = headerHeight();
        panel.setPreferredSize(new Dimension(0, height));
        panel.setMinimumSize(new Dimension(0, height));
        return panel;
    }

    /**
     * Height of a heading block, measured from real components so it follows
     * the current font and display scaling rather than a hard-coded value.
     */
    public static int headerHeight() {
        if (cachedHeaderHeight < 0) {
            JLabel probeTitle = new JLabel("Ag", AppIcons.info(18, "App.accent"), SwingConstants.LEADING);
            probeTitle.setIconTextGap(8);
            probeTitle.setFont(probeTitle.getFont().deriveFont(Font.BOLD, 15f));

            JTextField probeField = textField("Ag");

            cachedHeaderHeight = probeTitle.getPreferredSize().height
                    + HEADER_GAP
                    + probeField.getPreferredSize().height;
        }
        return cachedHeaderHeight;
    }

    /** Plain label used inline next to a field, e.g. "Machine:". */
    public static JLabel inlineLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(label.getFont().deriveFont(Font.PLAIN, 12f));
        return label;
    }

    // ---------------------------------------------------------------- panels

    /** Transparent panel — lets the parent's background show through. */
    public static JPanel transparent(LayoutManager layout) {
        JPanel panel = new JPanel(layout);
        panel.setOpaque(false);
        return panel;
    }

    /** A rounded, bordered surface painted in the theme's card colour. */
    public static JPanel card(LayoutManager layout, int padding) {
        JPanel panel = new JPanel(layout);
        panel.setOpaque(false);
        panel.setBorder(new CardBorder(padding));
        return panel;
    }

    public static JPanel card(LayoutManager layout) {
        return card(layout, 14);
    }

    /** Root container for a pane: canvas background plus breathing room. */
    public static JPanel pane(LayoutManager layout) {
        JPanel panel = new JPanel(layout);
        panel.setOpaque(true);
        panel.setBorder(new EmptyBorder(GAP, GAP, GAP, GAP));
        ThemeManager.styleOnThemeChange(panel,
                p -> p.setBackground(ThemeManager.color("App.canvas", p.getBackground())));
        return panel;
    }

    // ---------------------------------------------------------------- inputs

    public static JTextField textField(String placeholder) {
        JTextField field = new JTextField();
        field.putClientProperty("JComponent.roundRect", Boolean.TRUE);
        if (placeholder != null) field.putClientProperty("JTextField.placeholderText", placeholder);
        field.setMargin(new Insets(5, 8, 5, 8));
        return field;
    }

    public static JTextField searchField(String placeholder) {
        JTextField field = textField(placeholder);
        field.putClientProperty("JTextField.leadingIcon", AppIcons.search(15, "App.subtleForeground"));
        field.putClientProperty("JTextField.showClearButton", Boolean.TRUE);
        return field;
    }

    public static JTextArea textArea(int rows, int columns) {
        JTextArea area = new JTextArea(rows, columns);
        area.setLineWrap(true);
        area.setWrapStyleWord(true);
        area.setMargin(new Insets(6, 8, 6, 8));
        return area;
    }

    /** Wraps a component in a rounded, borderless-inside scroll pane. */
    public static JScrollPane scroll(Component view) {
        JScrollPane scrollPane = new JScrollPane(view);
        scrollPane.putClientProperty("JComponent.roundRect", Boolean.TRUE);
        scrollPane.getViewport().setOpaque(false);
        scrollPane.setOpaque(false);
        return scrollPane;
    }

    /** Scroll pane with no border at all — for content already inside a card. */
    public static JScrollPane bareScroll(Component view) {
        JScrollPane scrollPane = scroll(view);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        scrollPane.setViewportBorder(null);
        return scrollPane;
    }

    public static <T> JComboBox<T> comboBox(T[] items) {
        JComboBox<T> combo = new JComboBox<>(items);
        combo.putClientProperty("JComponent.roundRect", Boolean.TRUE);
        return combo;
    }

    // --------------------------------------------------------------- buttons

    /** Filled accent button for the primary action on a screen. */
    public static JButton primary(String text, Icon icon) {
        JButton button = new JButton(text, icon);
        button.setIconTextGap(8);
        button.setFocusPainted(false);
        button.putClientProperty("JButton.buttonType", "roundRect");
        applyPrimaryColors(button);
        PRIMARY_BUTTONS.add(new WeakReference<>(button));
        return button;
    }

    /** Outlined button for secondary actions. */
    public static JButton secondary(String text, Icon icon) {
        JButton button = new JButton(text, icon);
        button.setIconTextGap(8);
        button.setFocusPainted(false);
        button.putClientProperty("JButton.buttonType", "roundRect");
        return button;
    }

    /** Small bordered icon button — used for the machine/user "x" remove action. */
    public static JButton compactIconButton(Icon icon, String tooltip) {
        JButton button = new JButton(icon);
        button.setToolTipText(tooltip);
        button.setFocusPainted(false);
        button.setMargin(new Insets(2, 6, 2, 6));
        button.putClientProperty("JButton.buttonType", "roundRect");
        button.putClientProperty("JButton.squareSize", Boolean.FALSE);
        return button;
    }

    /** Small accent-filled icon button — the "+" in the settings tables. */
    public static JButton compactPrimaryIconButton(Icon icon, String tooltip) {
        JButton button = compactIconButton(icon, tooltip);
        applyPrimaryColors(button);
        PRIMARY_BUTTONS.add(new WeakReference<>(button));
        return button;
    }

    /** Borderless icon-only button. */
    public static JButton iconButton(Icon icon, String tooltip) {
        JButton button = new JButton(icon);
        button.setToolTipText(tooltip);
        button.setFocusPainted(false);
        button.setBorder(new EmptyBorder(4, 4, 4, 4));
        button.putClientProperty("JButton.buttonType", "toolBarButton");
        return button;
    }

    private static void applyPrimaryColors(JButton button) {
        Color accent = ThemeManager.accent();
        button.setBackground(accent);
        button.setForeground(idealTextOn(accent));
        button.putClientProperty("JButton.hoverBackground", accent.darker());
        button.putClientProperty("JButton.pressedBackground", accent.darker().darker());
        button.putClientProperty("JButton.borderColor", accent);
    }

    private static Color idealTextOn(Color background) {
        return ThemeManager.color("App.onAccent", ThemeManager.readableOn(background));
    }

    // ----------------------------------------------------------- date picker

    /** A LGoodDatePicker restyled to match the theme, with rounded corners. */
    public static DatePicker datePicker() {
        DatePickerSettings settings = new DatePickerSettings();
        settings.setFormatForDatesCommonEra(DateTimeFormatter.ofPattern("yyyy-MM-dd"));

        DatePicker picker = new DatePicker(settings);
        DATE_PICKERS.add(new WeakReference<>(picker));
        stylePicker(picker);
        return picker;
    }

    private static void stylePicker(DatePicker picker) {
        Color card = ThemeManager.card();
        Color accent = ThemeManager.accent();
        Color foreground = ThemeManager.color("App.foreground", Color.DARK_GRAY);
        Color subtle = ThemeManager.subtle();
        Color soft = ThemeManager.color("App.accentSoft", ThemeManager.blend(accent, card, 0.16f));

        DatePickerSettings settings = picker.getSettings();
        if (settings != null) {
            // Resolved by name so the code survives LGoodDatePicker version changes.
            for (DatePickerSettings.DateArea area : DatePickerSettings.DateArea.values()) {
                Color color = colorForDateArea(area.name(), card, foreground, subtle, soft, accent);
                if (color != null) {
                    try {
                        settings.setColor(area, color);
                    } catch (RuntimeException ignored) {
                        // unknown area in this version — safe to skip
                    }
                }
            }
        }

        picker.setOpaque(false);
        picker.setBorder(new RoundedFieldBorder());

        JTextField editor = picker.getComponentDateTextField();
        if (editor != null) {
            editor.setOpaque(false);
            editor.setBorder(new EmptyBorder(0, 2, 0, 2));
            editor.setForeground(foreground);
            editor.setCaretColor(foreground);
            editor.setBackground(card);
        }

        JButton toggle = picker.getComponentToggleCalendarButton();
        if (toggle != null) {
            toggle.setText("");
            toggle.setIcon(AppIcons.calendar(15, "App.subtleForeground"));
            toggle.setFocusPainted(false);
            toggle.setContentAreaFilled(false);
            toggle.setBorderPainted(false);
            toggle.setOpaque(false);
            toggle.setBorder(new EmptyBorder(2, 6, 2, 4));
            toggle.setToolTipText("Pick a date");
            toggle.putClientProperty("JButton.buttonType", "toolBarButton");
        }
    }

    private static Color colorForDateArea(String name, Color card, Color foreground,
                                          Color subtle, Color soft, Color accent) {
        if (name.startsWith("TextFieldBackground")) return card;
        if (name.startsWith("DatePickerText")) return foreground;
        if (name.equals("CalendarBackgroundSelectedDate")) return soft;
        if (name.equals("CalendarBorderSelectedDate")) return accent;
        if (name.startsWith("CalendarBackground")) return card;
        if (name.startsWith("CalendarDefaultBackground")) return ThemeManager.color("App.stripe", card);
        if (name.startsWith("CalendarDefaultText")) return foreground;
        if (name.equals("CalendarTextWeekdays") || name.equals("CalendarTextWeekNumbers")) return subtle;
        if (name.startsWith("CalendarText")) return foreground;
        if (name.startsWith("Background")) return card;
        return null;
    }

    // ---------------------------------------------------------------- tables

    /** Applies the shared table look: pill statuses, striped rows, soft grid. */
    public static void styleTable(JTable table) {
        table.setRowHeight(28);
        table.setFillsViewportHeight(true);
        table.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);

        JTableHeader header = table.getTableHeader();
        header.setReorderingAllowed(false);
        header.setDefaultRenderer(new HeaderRenderer());

        DefaultTableCellRenderer padded = new PaddedCellRenderer();
        table.setDefaultRenderer(Object.class, padded);
    }

    /** Renders a status column as a coloured pill. */
    public static TableCellRenderer statusRenderer() {
        return new StatusRenderer();
    }

    // -------------------------------------------------------------- refresh

    private static void refreshRegisteredComponents() {
        Iterator<WeakReference<DatePicker>> pickers = DATE_PICKERS.iterator();
        while (pickers.hasNext()) {
            DatePicker picker = pickers.next().get();
            if (picker == null) {
                pickers.remove();
                continue;
            }
            stylePicker(picker);
            picker.revalidate();
            picker.repaint();
        }

        Iterator<WeakReference<JButton>> buttons = PRIMARY_BUTTONS.iterator();
        while (buttons.hasNext()) {
            JButton button = buttons.next().get();
            if (button == null) {
                buttons.remove();
                continue;
            }
            applyPrimaryColors(button);
            button.repaint();
        }
    }

    // --------------------------------------------------------------- borders

    /**
     * Paints a rounded card surface. Borders are painted before children, so
     * filling here keeps the rounded corners visible behind the content.
     */
    public static final class CardBorder extends AbstractBorder {
        private final int padding;
        private final int arc;

        public CardBorder(int padding) {
            this(padding, 14);
        }

        public CardBorder(int padding, int arc) {
            this.padding = padding;
            this.arc = arc;
        }

        @Override
        public void paintBorder(Component c, Graphics graphics, int x, int y, int width, int height) {
            Graphics2D g = (Graphics2D) graphics.create();
            try {
                g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                RoundRectangle2D shape = new RoundRectangle2D.Double(
                        x + 0.5, y + 0.5, width - 1.0, height - 1.0, arc, arc);
                g.setColor(ThemeManager.card());
                g.fill(shape);
                g.setColor(ThemeManager.border());
                g.setStroke(new BasicStroke(1f));
                g.draw(shape);
            } finally {
                g.dispose();
            }
        }

        @Override
        public Insets getBorderInsets(Component c) {
            return new Insets(padding, padding, padding, padding);
        }

        @Override
        public Insets getBorderInsets(Component c, Insets insets) {
            insets.set(padding, padding, padding, padding);
            return insets;
        }
    }

    /** Rounded input-field surface used to wrap the date picker. */
    public static final class RoundedFieldBorder extends AbstractBorder {
        private final int arc = 10;

        @Override
        public void paintBorder(Component c, Graphics graphics, int x, int y, int width, int height) {
            Graphics2D g = (Graphics2D) graphics.create();
            try {
                g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                RoundRectangle2D shape = new RoundRectangle2D.Double(
                        x + 0.5, y + 0.5, width - 1.0, height - 1.0, arc, arc);
                g.setColor(ThemeManager.card());
                g.fill(shape);
                g.setColor(c.isEnabled() ? ThemeManager.border() : ThemeManager.subtle());
                g.setStroke(new BasicStroke(1f));
                g.draw(shape);
            } finally {
                g.dispose();
            }
        }

        @Override
        public Insets getBorderInsets(Component c) {
            return new Insets(4, 8, 4, 4);
        }

        @Override
        public Insets getBorderInsets(Component c, Insets insets) {
            insets.set(4, 8, 4, 4);
            return insets;
        }
    }

    /** One-pixel rule in the theme's border colour. */
    public static Border separator(int top, int bottom) {
        return new AbstractBorder() {
            @Override
            public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
                g.setColor(ThemeManager.border());
                g.fillRect(x, y + height - 1, width, 1);
            }

            @Override
            public Insets getBorderInsets(Component c) {
                return new Insets(top, 0, bottom, 0);
            }
        };
    }

    // ------------------------------------------------------------- renderers

    private static final class HeaderRenderer extends DefaultTableCellRenderer {
        HeaderRenderer() {
            setHorizontalAlignment(SwingConstants.LEADING);
            setBorder(new EmptyBorder(7, 10, 7, 10));
            setOpaque(true);
        }

        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean selected,
                                                       boolean focused, int row, int column) {
            super.getTableCellRendererComponent(table, value, selected, focused, row, column);
            setFont(table.getFont().deriveFont(Font.BOLD, 12f));
            setBackground(ThemeManager.color("App.tableHeaderBackground", ThemeManager.card()));
            setForeground(ThemeManager.color("App.tableHeaderForeground", ThemeManager.accent()));
            return this;
        }

        @Override
        protected void paintBorder(Graphics g) {
            super.paintBorder(g);
            g.setColor(ThemeManager.border());
            g.fillRect(0, getHeight() - 1, getWidth(), 1);
            g.fillRect(getWidth() - 1, 4, 1, getHeight() - 8);
        }
    }

    private static final class PaddedCellRenderer extends DefaultTableCellRenderer {
        PaddedCellRenderer() {
            setBorder(new EmptyBorder(0, 10, 0, 10));
        }

        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean selected,
                                                       boolean focused, int row, int column) {
            super.getTableCellRendererComponent(table, value, selected, focused, row, column);
            setBorder(new EmptyBorder(0, 10, 0, 10));
            return this;
        }
    }

    private static final class StatusRenderer extends DefaultTableCellRenderer {
        private String text = "";

        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean selected,
                                                       boolean focused, int row, int column) {
            super.getTableCellRendererComponent(table, value, selected, focused, row, column);
            text = value == null ? "" : value.toString();
            setText("");
            setBorder(new EmptyBorder(0, 10, 0, 10));
            return this;
        }

        @Override
        protected void paintComponent(Graphics graphics) {
            super.paintComponent(graphics);
            if (text.isEmpty()) return;

            Graphics2D g = (Graphics2D) graphics.create();
            try {
                g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,
                        RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

                Font font = getFont().deriveFont(Font.BOLD, 11f);
                g.setFont(font);
                FontMetrics metrics = g.getFontMetrics();

                int textWidth = metrics.stringWidth(text);
                int pillWidth = textWidth + 20;
                int pillHeight = Math.min(getHeight() - 8, 20);
                int x = 10;
                int y = (getHeight() - pillHeight) / 2;

                g.setColor(badgeBackground(text));
                g.fill(new RoundRectangle2D.Double(x, y, pillWidth, pillHeight, pillHeight, pillHeight));
                g.setColor(badgeForeground(text));
                int baseline = y + (pillHeight - metrics.getHeight()) / 2 + metrics.getAscent();
                g.drawString(text, x + 10, baseline);
            } finally {
                g.dispose();
            }
        }

        private Color badgeBackground(String status) {
            if ("Done".equalsIgnoreCase(status)) return ThemeManager.color("App.badgeDoneBg", Color.LIGHT_GRAY);
            if ("In Progress".equalsIgnoreCase(status)) return ThemeManager.color("App.badgeProgressBg", Color.LIGHT_GRAY);
            return ThemeManager.color("App.badgeTodoBg", Color.LIGHT_GRAY);
        }

        private Color badgeForeground(String status) {
            if ("Done".equalsIgnoreCase(status)) return ThemeManager.color("App.badgeDoneFg", Color.DARK_GRAY);
            if ("In Progress".equalsIgnoreCase(status)) return ThemeManager.color("App.badgeProgressFg", Color.DARK_GRAY);
            return ThemeManager.color("App.badgeTodoFg", Color.DARK_GRAY);
        }
    }
}
