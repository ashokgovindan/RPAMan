package rpa.rpaman;

/** A change request received against one RPA, tracked through to delivery. */
public class ChangeRequest {

    public static final String[] STATUSES = {
            "New", "Analysis", "In Development", "Testing", "UAT",
            "Deployed", "Rejected", "On Hold"
    };

    public static final String[] PRIORITIES = {"Low", "Medium", "High", "Critical"};

    /** Database id; 0 means the row has not been saved yet. */
    public int id;

    public String projectName = "";
    public String crNumber = "";
    public String title = "";
    public String requestedBy = "";
    public String receivedDate = "";
    public String priority = "Medium";
    public String status = "New";
    public String targetDate = "";
    public String deliveredDate = "";
    public String notes = "";

    /** Deployment that shipped this CR; 0 when not linked yet. */
    public int deploymentId;
}
