package rpa.rpaman;

import com.formdev.flatlaf.FlatDarkLaf;
import com.formdev.flatlaf.FlatLaf;
import com.formdev.flatlaf.FlatLightLaf;

import javax.swing.*;
import javax.swing.plaf.ColorUIResource;
import javax.swing.plaf.FontUIResource;
import java.awt.*;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Consumer;

/**
 * Central place for the application's visual identity.
 * <p>
 * Installs FlatLaf, publishes a small palette of {@code App.*} colours into
 * {@link UIManager} and lets the rest of the UI re-read them whenever the
 * user picks a different theme.
 */
public final class ThemeManager {

    public static final String SETTING_KEY = "ui.theme";

    /** The three curated themes exposed in the View &gt; Themes menu. */
    public enum Theme {

        LIGHT("Light", false,
                "#0F6CBD",   // accent
                "#FFFFFF",   // window / panel background
                "#FFFFFF",   // card
                "#EEF3FA",   // canvas (details area)
                "#D7DFEA",   // border
                "#F5F9FE",   // stripe
                "#DCE8F7",   // table header background
                "#14508F",   // table header foreground
                "#5E6C82"),  // subtle foreground

        BLUE("Blue", false,
                "#1565C0",
                "#EAF1FB",
                "#FFFFFF",
                "#DCE9F9",
                "#BFD4EC",
                "#F2F7FE",
                "#C9DDF5",
                "#0D4A8F",
                "#4A5F7A"),

        DARK("Dark", true,
                "#4C9AFF",
                "#2B2F36",
                "#333841",
                "#24282E",
                "#414753",
                "#2F343C",
                "#363C46",
                "#9EC5FF",
                "#98A3B3");

        public final String displayName;
        public final boolean dark;
        final String accent, background, card, canvas, border, stripe, headerBg, headerFg, subtle;

        Theme(String displayName, boolean dark, String accent, String background, String card,
              String canvas, String border, String stripe, String headerBg, String headerFg, String subtle) {
            this.displayName = displayName;
            this.dark = dark;
            this.accent = accent;
            this.background = background;
            this.card = card;
            this.canvas = canvas;
            this.border = border;
            this.stripe = stripe;
            this.headerBg = headerBg;
            this.headerFg = headerFg;
            this.subtle = subtle;
        }
    }

    private static final List<Runnable> REFRESHERS = new ArrayList<>();
    private static final List<StyleHook<?>> STYLE_HOOKS = new ArrayList<>();
    private static Theme current = Theme.LIGHT;
    private static DatabaseManager db;
    private static Set<String> availableFonts;

    private ThemeManager() {
    }

    // ---------------------------------------------------------------- lifecycle

    /** Installs the last theme the user chose (or Light on first run). */
    public static void init(DatabaseManager databaseManager) {
        db = databaseManager;
        Theme startup = Theme.LIGHT;
        if (db != null) {
            String saved = db.getSetting(SETTING_KEY, Theme.LIGHT.name());
            for (Theme t : Theme.values()) {
                if (t.name().equalsIgnoreCase(saved)) {
                    startup = t;
                    break;
                }
            }
        }
        current = startup;
        install(startup);
    }

    /** Switches theme at runtime and repaints every open window. */
    public static void setTheme(Theme theme) {
        if (theme == null) return;
        current = theme;
        install(theme);
        if (db != null) db.setSetting(SETTING_KEY, theme.name());

        FlatLaf.updateUI();
        for (Runnable r : new ArrayList<>(REFRESHERS)) {
            try {
                r.run();
            } catch (RuntimeException ignored) {
                // a single misbehaving component must not break the switch
            }
        }
        // Re-style tracked components, dropping any that have been collected
        Iterator<StyleHook<?>> hooks = STYLE_HOOKS.iterator();
        while (hooks.hasNext()) {
            StyleHook<?> hook = hooks.next();
            try {
                if (!hook.apply()) hooks.remove();
            } catch (RuntimeException ignored) {
                hooks.remove();
            }
        }
        for (Window w : Window.getWindows()) {
            w.invalidate();
            w.validate();
            w.repaint();
        }
    }

    public static Theme current() {
        return current;
    }

    public static boolean isDark() {
        return current.dark;
    }

    /**
     * Registers a callback invoked after every theme change. Use it for
     * components whose colours cannot be derived lazily at paint time.
     */
    public static void onThemeChanged(Runnable r) {
        if (r != null) REFRESHERS.add(r);
    }

    /**
     * Re-applies {@code styler} to {@code component} on every theme change.
     * <p>
     * The component is held weakly and the styler must not capture it, so
     * short-lived windows such as the settings dialog can be garbage collected.
     */
    public static <T extends Component> void styleOnThemeChange(T component, Consumer<T> styler) {
        if (component == null || styler == null) return;
        styler.accept(component);
        STYLE_HOOKS.add(new StyleHook<>(component, styler));
    }

    /** A weakly-held component plus the code that re-styles it. */
    private static final class StyleHook<T extends Component> {
        private final WeakReference<T> ref;
        private final Consumer<T> styler;

        StyleHook(T component, Consumer<T> styler) {
            this.ref = new WeakReference<>(component);
            this.styler = styler;
        }

        /** Returns false once the component has been collected. */
        boolean apply() {
            T component = ref.get();
            if (component == null) return false;
            styler.accept(component);
            return true;
        }
    }

    // ---------------------------------------------------------------- install

    private static void install(Theme t) {
        Map<String, String> extra = new LinkedHashMap<>();
        extra.put("@accentColor", t.accent);
        extra.put("@background", t.background);
        FlatLaf.setGlobalExtraDefaults(extra);

        installFont();

        if (t.dark) {
            FlatDarkLaf.setup();
        } else {
            FlatLightLaf.setup();
        }

        applyShape();
        applyPalette(t);
    }

    /** Rounded corners, roomy rows, slim scrollbars. */
    private static void applyShape() {
        UIManager.put("Component.arc", 12);
        UIManager.put("Button.arc", 12);
        UIManager.put("TextComponent.arc", 10);
        UIManager.put("CheckBox.arc", 5);
        UIManager.put("ProgressBar.arc", 10);
        UIManager.put("Component.focusWidth", 1);
        UIManager.put("Component.innerFocusWidth", 1);
        UIManager.put("Button.innerFocusWidth", 1);
        UIManager.put("Component.hideMnemonics", Boolean.TRUE);

        UIManager.put("ScrollBar.width", 12);
        UIManager.put("ScrollBar.thumbArc", 999);
        UIManager.put("ScrollBar.thumbInsets", new Insets(2, 2, 2, 2));
        UIManager.put("ScrollBar.showButtons", Boolean.FALSE);
        UIManager.put("ScrollPane.smoothScrolling", Boolean.TRUE);

        UIManager.put("Tree.rowHeight", 26);
        UIManager.put("Tree.paintLines", Boolean.FALSE);
        UIManager.put("Tree.showDefaultIcons", Boolean.FALSE);
        // the renderer draws its own rounded selection pill
        UIManager.put("Tree.wideSelection", Boolean.FALSE);
        UIManager.put("Table.rowHeight", 26);
        UIManager.put("Table.showHorizontalLines", Boolean.TRUE);
        UIManager.put("Table.showVerticalLines", Boolean.TRUE);
        // 1px spacing so the grid lines are actually visible under FlatLaf
        UIManager.put("Table.intercellSpacing", new Dimension(1, 1));

        UIManager.put("MenuItem.selectionArc", 8);
        UIManager.put("PopupMenu.borderInsets", new Insets(6, 6, 6, 6));

        UIManager.put("SplitPane.dividerSize", 6);
        UIManager.put("SplitPane.oneTouchButtonSize", 0);
        UIManager.put("TitlePane.unifiedBackground", Boolean.TRUE);
        UIManager.put("ToolTip.paintBackground", Boolean.TRUE);
    }

    /** Publishes the {@code App.*} palette consumed across the app. */
    private static void applyPalette(Theme t) {
        put("App.accent", t.accent);
        put("App.card", t.card);
        put("App.canvas", t.canvas);
        put("App.border", t.border);
        put("App.stripe", t.stripe);
        put("App.tableHeaderBackground", t.headerBg);
        put("App.tableHeaderForeground", t.headerFg);
        put("App.subtleForeground", t.subtle);

        Color accent = hex(t.accent);
        Color card = hex(t.card);
        UIManager.put("App.accentSoft", new ColorUIResource(blend(accent, card, 0.16f)));
        UIManager.put("App.accentHover", new ColorUIResource(blend(accent, card, 0.30f)));
        UIManager.put("App.icon", new ColorUIResource(hex(t.subtle)));
        UIManager.put("App.foreground", UIManager.getColor("Label.foreground"));
        UIManager.put("App.onAccent", new ColorUIResource(readableOn(accent)));

        UIManager.put("Table.alternateRowColor", new ColorUIResource(hex(t.stripe)));
        UIManager.put("Table.gridColor", new ColorUIResource(blend(hex(t.border), card, 0.55f)));
        UIManager.put("Tree.selectionBackground", new ColorUIResource(blend(accent, card, 0.18f)));
        UIManager.put("Tree.selectionForeground", UIManager.getColor("Tree.foreground"));
        UIManager.put("Tree.selectionInactiveBackground", new ColorUIResource(blend(accent, card, 0.10f)));
        UIManager.put("Table.selectionBackground", new ColorUIResource(blend(accent, card, 0.22f)));
        UIManager.put("Table.selectionForeground", UIManager.getColor("Table.foreground"));
        UIManager.put("Table.selectionInactiveBackground", new ColorUIResource(blend(accent, card, 0.12f)));

        // Status badge colours used by the tasks table
        if (t.dark) {
            put("App.badgeTodoBg", "#3A414D");
            put("App.badgeTodoFg", "#C6CFDC");
            put("App.badgeProgressBg", "#4A3B1E");
            put("App.badgeProgressFg", "#F2C46B");
            put("App.badgeDoneBg", "#1F4034");
            put("App.badgeDoneFg", "#79D3A5");
            put("App.badgeErrorBg", "#4A2A2A");
            put("App.badgeErrorFg", "#F09393");
        } else {
            put("App.badgeTodoBg", "#E6EBF2");
            put("App.badgeTodoFg", "#4A5768");
            put("App.badgeProgressBg", "#FDF0D5");
            put("App.badgeProgressFg", "#96631A");
            put("App.badgeDoneBg", "#DCF3E6");
            put("App.badgeDoneFg", "#1E7A4C");
            put("App.badgeErrorBg", "#FBE1E1");
            put("App.badgeErrorFg", "#B3261E");
        }
    }

    private static void installFont() {
        if (availableFonts == null) {
            availableFonts = new HashSet<>(Arrays.asList(GraphicsEnvironment
                    .getLocalGraphicsEnvironment().getAvailableFontFamilyNames()));
        }
        String[] preferred = {"Segoe UI Variable Text", "Segoe UI", "Inter",
                "SF Pro Text", "Roboto", "Noto Sans", "DejaVu Sans"};
        for (String family : preferred) {
            if (availableFonts.contains(family)) {
                UIManager.put("defaultFont", new FontUIResource(family, Font.PLAIN, 13));
                return;
            }
        }
    }

    // ---------------------------------------------------------------- colours

    private static void put(String key, String hex) {
        UIManager.put(key, new ColorUIResource(hex(hex)));
    }

    public static Color hex(String value) {
        return Color.decode(value);
    }

    /** Picks white or near-black text so it stays legible on {@code background}. */
    public static Color readableOn(Color background) {
        double luminance = (0.299 * background.getRed()
                + 0.587 * background.getGreen()
                + 0.114 * background.getBlue()) / 255.0;
        return luminance > 0.62 ? new Color(0x10, 0x18, 0x24) : Color.WHITE;
    }

    /** Mixes {@code ratio} of {@code fg} into {@code bg}. */
    public static Color blend(Color fg, Color bg, float ratio) {
        float r = Math.max(0f, Math.min(1f, ratio));
        return new Color(
                Math.round(fg.getRed() * r + bg.getRed() * (1 - r)),
                Math.round(fg.getGreen() * r + bg.getGreen() * (1 - r)),
                Math.round(fg.getBlue() * r + bg.getBlue() * (1 - r)));
    }

    /** {@link UIManager} colour lookup with a fallback. */
    public static Color color(String key, Color fallback) {
        Color c = UIManager.getColor(key);
        return c != null ? new Color(c.getRGB(), true) : fallback;
    }

    public static Color accent() {
        return color("App.accent", new Color(0x0F6CBD));
    }

    public static Color card() {
        return color("App.card", Color.WHITE);
    }

    public static Color border() {
        return color("App.border", new Color(0xD7DFEA));
    }

    public static Color subtle() {
        return color("App.subtleForeground", Color.GRAY);
    }
}
