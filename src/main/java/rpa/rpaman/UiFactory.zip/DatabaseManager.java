package rpa.rpaman;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class DatabaseManager {
    private static final String DB_URL = "jdbc:sqlite:rpa_manager.db";

    public DatabaseManager() {
        initializeDatabase();
    }

    private void initializeDatabase() {
        // SQL statements to create tables
        String createTasksTable = "CREATE TABLE IF NOT EXISTS Tasks (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "description TEXT NOT NULL, " +
                "due_date TEXT, " +
                "status TEXT)";

        String createProjectsTable = "CREATE TABLE IF NOT EXISTS Projects (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "name TEXT UNIQUE NOT NULL)";

        String createTemplateNodesTable = "CREATE TABLE IF NOT EXISTS TemplateNodes (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "project_name TEXT, " +
                "node_name TEXT, " +
                "is_selected INTEGER DEFAULT 0, " +
                "completion_date TEXT, " +
                "comments TEXT, " +
                "UNIQUE(project_name, node_name))";

        String createSettingsTable = "CREATE TABLE IF NOT EXISTS Settings (" +
                "key TEXT PRIMARY KEY, " +
                "value TEXT)";

        String createProjectConfigTable = "CREATE TABLE IF NOT EXISTS ProjectConfig (" +
                "project_name TEXT PRIMARY KEY, " +
                "db_path TEXT, " +
                "received_query TEXT, " +
                "pending_query TEXT, " +
                "processed_query TEXT)";

        String createProjectMachinesTable = "CREATE TABLE IF NOT EXISTS ProjectMachines (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "project_name TEXT NOT NULL, " +
                "machine_name TEXT, " +
                "user_name TEXT)";

        String createTemplateItemsTable = "CREATE TABLE IF NOT EXISTS TemplateItems (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "name TEXT UNIQUE NOT NULL, " +
                "sort_order INTEGER DEFAULT 0)";

        String createUrlItemsTable = "CREATE TABLE IF NOT EXISTS UrlItems (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "category TEXT, " +
                "name TEXT NOT NULL, " +
                "url TEXT, " +
                "sort_order INTEGER DEFAULT 0)";

        String createApplicationsTable = "CREATE TABLE IF NOT EXISTS Applications (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "name TEXT UNIQUE NOT NULL, " +
                "sort_order INTEGER DEFAULT 0)";

        String createProjectApplicationsTable = "CREATE TABLE IF NOT EXISTS ProjectApplications (" +
                "project_name TEXT NOT NULL, " +
                "application_name TEXT NOT NULL, " +
                "UNIQUE(project_name, application_name))";

        String createDeploymentsTable = "CREATE TABLE IF NOT EXISTS Deployments (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "project_name TEXT NOT NULL, " +
                "name TEXT, " +
                "ritm_number TEXT, " +
                "environment TEXT, " +
                "requested_date TEXT, " +
                "deployed_date TEXT, " +
                "status TEXT, " +
                "requested_by TEXT, " +
                "change_description TEXT, " +
                "tasks_to_deploy TEXT, " +
                "test_log_path TEXT, " +
                "code_analysis_path TEXT, " +
                "code_moved_to_test TEXT, " +
                "notes TEXT)";

        String createChangeRequestsTable = "CREATE TABLE IF NOT EXISTS ChangeRequests (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "project_name TEXT NOT NULL, " +
                "cr_number TEXT, " +
                "title TEXT, " +
                "requested_by TEXT, " +
                "received_date TEXT, " +
                "priority TEXT, " +
                "status TEXT, " +
                "target_date TEXT, " +
                "delivered_date TEXT, " +
                "deployment_id INTEGER DEFAULT 0, " +
                "notes TEXT)";

        String createAaActivityTable = "CREATE TABLE IF NOT EXISTS AaActivity (" +
                "id TEXT PRIMARY KEY, " +
                "activity_name TEXT, " +
                "automation_name TEXT, " +
                "automation_type TEXT, " +
                "device_name TEXT, " +
                "run_as_user TEXT, " +
                "status TEXT, " +
                "running_time TEXT, " +
                "activity_type TEXT, " +
                "started_on TEXT, " +
                "started_display TEXT, " +
                "ended_on TEXT, " +
                "fetched_at TEXT)";

        try (Connection conn = DriverManager.getConnection(DB_URL);
             Statement stmt = conn.createStatement()) {

            stmt.execute(createTasksTable);
            stmt.execute(createProjectsTable);
            stmt.execute(createTemplateNodesTable);
            stmt.execute(createSettingsTable);
            stmt.execute(createProjectConfigTable);
            stmt.execute(createProjectMachinesTable);
            stmt.execute(createTemplateItemsTable);
            stmt.execute(createUrlItemsTable);
            stmt.execute(createApplicationsTable);
            stmt.execute(createProjectApplicationsTable);
            stmt.execute(createDeploymentsTable);
            stmt.execute(createChangeRequestsTable);
            stmt.execute(createAaActivityTable);

            migrateSchema(conn);

        } catch (SQLException e) {
            System.err.println("Database initialization error: " + e.getMessage());
        }

        seedDefaultTemplateItems();
        seedDefaultProjects();
    }

    // ================= PROJECTS =================

    /** Keeps the projects that shipped with the app available on first run. */
    private void seedDefaultProjects() {
        if (!getProjectNames().isEmpty()) return;
        for (String name : new String[]{"NAR Umbrella", "Another Test", "Test33"}) {
            addProject(name);
        }
    }

    /** All project names, in creation order. */
    public List<String> getProjectNames() {
        List<String> names = new ArrayList<>();
        String sql = "SELECT name FROM Projects ORDER BY id";
        try (Connection conn = DriverManager.getConnection(DB_URL);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                names.add(safe(rs.getString("name")));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return names;
    }

    /** Adds a project. Returns false when the name is blank or already taken. */
    public boolean addProject(String name) {
        if (name == null || name.trim().isEmpty()) return false;
        String sql = "INSERT OR IGNORE INTO Projects (name) VALUES (?)";
        try (Connection conn = DriverManager.getConnection(DB_URL);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, name.trim());
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    /** True when a project with this name already exists (case-insensitive). */
    public boolean projectExists(String name) {
        if (name == null) return false;
        String sql = "SELECT 1 FROM Projects WHERE name = ? COLLATE NOCASE";
        try (Connection conn = DriverManager.getConnection(DB_URL);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, name.trim());
            return pstmt.executeQuery().next();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // ================= GLOBAL TEMPLATE ITEMS =================

    /** Populates the template list on first run so the app is usable immediately. */
    private void seedDefaultTemplateItems() {
        if (!getTemplateItems().isEmpty()) return;
        String[] defaults = {
                "TPM Name Requested", "TPM Entry", "Qualification", "Define",
                "BCA", "Development", "Deployment", "Prod Validation"
        };
        for (String name : defaults) {
            addTemplateItem(name);
        }
    }

    /** The template nodes every project gets, in display order. */
    public List<String> getTemplateItems() {
        List<String> items = new ArrayList<>();
        String sql = "SELECT name FROM TemplateItems ORDER BY sort_order, id";
        try (Connection conn = DriverManager.getConnection(DB_URL);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                items.add(safe(rs.getString("name")));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return items;
    }

    /** Appends a template item. Returns false when the name already exists. */
    public boolean addTemplateItem(String name) {
        if (name == null || name.trim().isEmpty()) return false;
        String sql = "INSERT OR IGNORE INTO TemplateItems (name, sort_order) VALUES (?, " +
                "(SELECT IFNULL(MAX(sort_order), 0) + 1 FROM TemplateItems))";
        try (Connection conn = DriverManager.getConnection(DB_URL);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, name.trim());
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    /** Removes a template item and every per-project row that referenced it. */
    public void removeTemplateItem(String name) {
        try (Connection conn = DriverManager.getConnection(DB_URL)) {
            try (PreparedStatement pstmt = conn.prepareStatement(
                    "DELETE FROM TemplateItems WHERE name = ?")) {
                pstmt.setString(1, name);
                pstmt.executeUpdate();
            }
            try (PreparedStatement pstmt = conn.prepareStatement(
                    "DELETE FROM TemplateNodes WHERE node_name = ?")) {
                pstmt.setString(1, name);
                pstmt.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // ================= DEFAULT PROJECT URLS =================

    /** Returns URL rows as {@code {category, name, url}}, grouped by category. */
    public List<String[]> getUrlItems() {
        List<String[]> items = new ArrayList<>();
        String sql = "SELECT category, name, url FROM UrlItems ORDER BY category, sort_order, id";
        try (Connection conn = DriverManager.getConnection(DB_URL);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                items.add(new String[]{
                        safe(rs.getString("category")),
                        safe(rs.getString("name")),
                        safe(rs.getString("url"))
                });
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return items;
    }

    /** Replaces the whole URL list in one transaction. */
    public void replaceUrlItems(List<String[]> items) {
        try (Connection conn = DriverManager.getConnection(DB_URL)) {
            conn.setAutoCommit(false);
            try {
                try (Statement stmt = conn.createStatement()) {
                    stmt.execute("DELETE FROM UrlItems");
                }
                try (PreparedStatement insert = conn.prepareStatement(
                        "INSERT INTO UrlItems (category, name, url, sort_order) VALUES (?, ?, ?, ?)")) {
                    int order = 0;
                    for (String[] item : items) {
                        insert.setString(1, item.length > 0 ? safe(item[0]) : "");
                        insert.setString(2, item.length > 1 ? safe(item[1]) : "");
                        insert.setString(3, item.length > 2 ? safe(item[2]) : "");
                        insert.setInt(4, order++);
                        insert.addBatch();
                    }
                    insert.executeBatch();
                }
                conn.commit();
            } catch (SQLException e) {
                conn.rollback();
                throw e;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // ================= TASKS CRUD OPERATIONS =================

    public void addTask(String description, String dueDate, String status) {
        String sql = "INSERT INTO Tasks(description, due_date, status) VALUES(?,?,?)";
        try (Connection conn = DriverManager.getConnection(DB_URL);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, description);
            pstmt.setString(2, dueDate);
            pstmt.setString(3, status);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateTask(int id, String description, String dueDate, String status) {
        String sql = "UPDATE Tasks SET description = ?, due_date = ?, status = ? WHERE id = ?";
        try (Connection conn = DriverManager.getConnection(DB_URL);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, description);
            pstmt.setString(2, dueDate);
            pstmt.setString(3, status);
            pstmt.setInt(4, id);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Object[]> getAllTasks() {
        List<Object[]> tasks = new ArrayList<>();
        String sql = "SELECT id, description, due_date, status FROM Tasks";
        try (Connection conn = DriverManager.getConnection(DB_URL);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                tasks.add(new Object[]{
                        rs.getInt("id"),
                        rs.getString("description"),
                        rs.getString("due_date"),
                        rs.getString("status")
                });
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return tasks;
    }

    // ================= TREE NODE STATE OPERATIONS =================

    public void saveNodeState(String projectName, String nodeName, boolean isSelected) {
        String sql = "INSERT INTO TemplateNodes (project_name, node_name, is_selected) VALUES (?, ?, ?) " +
                "ON CONFLICT(project_name, node_name) DO UPDATE SET is_selected = ?";
        try (Connection conn = DriverManager.getConnection(DB_URL);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, projectName);
            pstmt.setString(2, nodeName);
            pstmt.setInt(3, isSelected ? 1 : 0);
            pstmt.setInt(4, isSelected ? 1 : 0);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public boolean isNodeSelected(String projectName, String nodeName) {
        String sql = "SELECT is_selected FROM TemplateNodes WHERE project_name = ? AND node_name = ?";
        try (Connection conn = DriverManager.getConnection(DB_URL);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, projectName);
            pstmt.setString(2, nodeName);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("is_selected") == 1;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // ================= TEMPLATE NODE DETAILS =================

    /**
     * Saves the completion date and comments for one template node.
     * The checkbox state of the node is deliberately left untouched.
     */
    public void saveTemplateDetails(String projectName, String nodeName,
                                    String completionDate, String comments) {
        String sql = "INSERT INTO TemplateNodes (project_name, node_name, completion_date, comments) " +
                "VALUES (?, ?, ?, ?) " +
                "ON CONFLICT(project_name, node_name) DO UPDATE SET completion_date = ?, comments = ?";
        try (Connection conn = DriverManager.getConnection(DB_URL);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, projectName);
            pstmt.setString(2, nodeName);
            pstmt.setString(3, completionDate);
            pstmt.setString(4, comments);
            pstmt.setString(5, completionDate);
            pstmt.setString(6, comments);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Returns {@code {completionDate, comments}} for a template node.
     * Missing values come back as empty strings, never {@code null}.
     */
    public String[] getTemplateDetails(String projectName, String nodeName) {
        String sql = "SELECT completion_date, comments FROM TemplateNodes " +
                "WHERE project_name = ? AND node_name = ?";
        try (Connection conn = DriverManager.getConnection(DB_URL);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, projectName);
            pstmt.setString(2, nodeName);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return new String[]{safe(rs.getString("completion_date")), safe(rs.getString("comments"))};
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return new String[]{"", ""};
    }

    // ================= PROJECT DATABASE CONFIGURATION =================

    /**
     * Returns {@code {dbPath, receivedQuery, pendingQuery, processedQuery}}
     * for a project, or four empty strings when nothing is stored yet.
     */
    public String[] getProjectConfig(String projectName) {
        String sql = "SELECT db_path, received_query, pending_query, processed_query " +
                "FROM ProjectConfig WHERE project_name = ?";
        try (Connection conn = DriverManager.getConnection(DB_URL);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, projectName);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return new String[]{
                        safe(rs.getString("db_path")),
                        safe(rs.getString("received_query")),
                        safe(rs.getString("pending_query")),
                        safe(rs.getString("processed_query"))
                };
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return new String[]{"", "", "", ""};
    }

    public void saveProjectConfig(String projectName, String dbPath, String receivedQuery,
                                  String pendingQuery, String processedQuery) {
        String sql = "INSERT INTO ProjectConfig " +
                "(project_name, db_path, received_query, pending_query, processed_query) " +
                "VALUES (?, ?, ?, ?, ?) " +
                "ON CONFLICT(project_name) DO UPDATE SET " +
                "db_path = ?, received_query = ?, pending_query = ?, processed_query = ?";
        try (Connection conn = DriverManager.getConnection(DB_URL);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, projectName);
            pstmt.setString(2, dbPath);
            pstmt.setString(3, receivedQuery);
            pstmt.setString(4, pendingQuery);
            pstmt.setString(5, processedQuery);
            pstmt.setString(6, dbPath);
            pstmt.setString(7, receivedQuery);
            pstmt.setString(8, pendingQuery);
            pstmt.setString(9, processedQuery);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /** Wipes the stored configuration and machine list for a project. */
    public void deleteProjectConfig(String projectName) {
        try (Connection conn = DriverManager.getConnection(DB_URL)) {
            try (PreparedStatement pstmt = conn.prepareStatement(
                    "DELETE FROM ProjectConfig WHERE project_name = ?")) {
                pstmt.setString(1, projectName);
                pstmt.executeUpdate();
            }
            try (PreparedStatement pstmt = conn.prepareStatement(
                    "DELETE FROM ProjectMachines WHERE project_name = ?")) {
                pstmt.setString(1, projectName);
                pstmt.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // ================= PROJECT MACHINES / USERS =================

    /** Returns the machine/user pairs of a project as {@code {machine, user}} rows. */
    public List<String[]> getMachines(String projectName) {
        List<String[]> machines = new ArrayList<>();
        String sql = "SELECT machine_name, user_name FROM ProjectMachines " +
                "WHERE project_name = ? ORDER BY id";
        try (Connection conn = DriverManager.getConnection(DB_URL);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, projectName);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                machines.add(new String[]{safe(rs.getString("machine_name")), safe(rs.getString("user_name"))});
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return machines;
    }

    /** Replaces the whole machine list of a project in a single transaction. */
    public void replaceMachines(String projectName, List<String[]> machines) {
        try (Connection conn = DriverManager.getConnection(DB_URL)) {
            conn.setAutoCommit(false);
            try {
                try (PreparedStatement delete = conn.prepareStatement(
                        "DELETE FROM ProjectMachines WHERE project_name = ?")) {
                    delete.setString(1, projectName);
                    delete.executeUpdate();
                }
                try (PreparedStatement insert = conn.prepareStatement(
                        "INSERT INTO ProjectMachines (project_name, machine_name, user_name) VALUES (?, ?, ?)")) {
                    for (String[] machine : machines) {
                        insert.setString(1, projectName);
                        insert.setString(2, machine.length > 0 ? machine[0] : "");
                        insert.setString(3, machine.length > 1 ? machine[1] : "");
                        insert.addBatch();
                    }
                    insert.executeBatch();
                }
                conn.commit();
            } catch (SQLException e) {
                conn.rollback();
                throw e;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // ================= SCHEMA MIGRATION =================

    /**
     * Adds columns introduced after a database was first created.
     * {@code CREATE TABLE IF NOT EXISTS} leaves existing tables untouched, so
     * new fields have to be added explicitly for anyone upgrading.
     */
    private void migrateSchema(Connection conn) {
        addColumnIfMissing(conn, "Deployments", "ritm_number", "TEXT");
        addColumnIfMissing(conn, "Deployments", "change_description", "TEXT");
        addColumnIfMissing(conn, "Deployments", "tasks_to_deploy", "TEXT");
        addColumnIfMissing(conn, "Deployments", "test_log_path", "TEXT");
        addColumnIfMissing(conn, "Deployments", "code_analysis_path", "TEXT");
        addColumnIfMissing(conn, "Deployments", "code_moved_to_test", "TEXT");
    }

    private void addColumnIfMissing(Connection conn, String table, String column, String type) {
        try {
            Set<String> existing = new HashSet<>();
            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery("PRAGMA table_info(" + table + ")")) {
                while (rs.next()) {
                    existing.add(rs.getString("name").toLowerCase());
                }
            }
            if (existing.contains(column.toLowerCase())) return;

            try (Statement stmt = conn.createStatement()) {
                stmt.execute("ALTER TABLE " + table + " ADD COLUMN " + column + " " + type);
            }
        } catch (SQLException e) {
            System.err.println("Could not add column " + table + "." + column + ": " + e.getMessage());
        }
    }

    // ================= DEPLOYMENTS =================

    public List<Deployment> getDeployments(String projectName) {
        List<Deployment> deployments = new ArrayList<>();
        String sql = "SELECT * FROM Deployments WHERE project_name = ? ORDER BY id";
        try (Connection conn = DriverManager.getConnection(DB_URL);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, projectName);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                deployments.add(readDeployment(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return deployments;
    }

    private Deployment readDeployment(ResultSet rs) throws SQLException {
        Deployment d = new Deployment();
        d.id = rs.getInt("id");
        d.projectName = safe(rs.getString("project_name"));
        d.name = safe(rs.getString("name"));
        d.ritmNumber = safe(rs.getString("ritm_number"));
        d.environment = safe(rs.getString("environment"));
        d.requestedDate = safe(rs.getString("requested_date"));
        d.deployedDate = safe(rs.getString("deployed_date"));
        d.status = safe(rs.getString("status"));
        d.requestedBy = safe(rs.getString("requested_by"));
        d.changeDescription = safe(rs.getString("change_description"));
        d.tasksToDeploy = safe(rs.getString("tasks_to_deploy"));
        d.testLogPath = safe(rs.getString("test_log_path"));
        d.codeAnalysisPath = safe(rs.getString("code_analysis_path"));
        d.codeMovedToTest = safe(rs.getString("code_moved_to_test"));
        d.notes = safe(rs.getString("notes"));
        return d;
    }

    /** Inserts a single deployment request, e.g. from the submission form. */
    public boolean addDeployment(Deployment d) {
        String sql = "INSERT INTO Deployments (project_name, name, ritm_number, environment, " +
                "requested_date, deployed_date, status, requested_by, change_description, " +
                "tasks_to_deploy, test_log_path, code_analysis_path, code_moved_to_test, notes) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DriverManager.getConnection(DB_URL);
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            bindDeployment(pstmt, d, d.projectName);
            pstmt.executeUpdate();
            try (ResultSet keys = pstmt.getGeneratedKeys()) {
                if (keys.next()) d.id = keys.getInt(1);
            }
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    private void bindDeployment(PreparedStatement pstmt, Deployment d, String projectName)
            throws SQLException {
        pstmt.setString(1, safe(projectName));
        pstmt.setString(2, safe(d.name));
        pstmt.setString(3, safe(d.ritmNumber));
        pstmt.setString(4, safe(d.environment));
        pstmt.setString(5, safe(d.requestedDate));
        pstmt.setString(6, safe(d.deployedDate));
        pstmt.setString(7, safe(d.status));
        pstmt.setString(8, safe(d.requestedBy));
        pstmt.setString(9, safe(d.changeDescription));
        pstmt.setString(10, safe(d.tasksToDeploy));
        pstmt.setString(11, safe(d.testLogPath));
        pstmt.setString(12, safe(d.codeAnalysisPath));
        pstmt.setString(13, safe(d.codeMovedToTest));
        pstmt.setString(14, safe(d.notes));
    }

    /**
     * Saves a project's deployments. Rows are matched on id rather than being
     * replaced wholesale, because change requests reference those ids.
     * Newly inserted deployments get their generated id written back.
     */
    public void saveDeployments(String projectName, List<Deployment> deployments) {
        try (Connection conn = DriverManager.getConnection(DB_URL)) {
            conn.setAutoCommit(false);
            try {
                // Delete deployments the user removed, along with their RITMs
                StringBuilder keep = new StringBuilder();
                for (Deployment d : deployments) {
                    if (d.id > 0) {
                        if (keep.length() > 0) keep.append(',');
                        keep.append(d.id);
                    }
                }
                String deleteSql = "DELETE FROM Deployments WHERE project_name = ?"
                        + (keep.length() > 0 ? " AND id NOT IN (" + keep + ")" : "");
                try (PreparedStatement pstmt = conn.prepareStatement(deleteSql)) {
                    pstmt.setString(1, projectName);
                    pstmt.executeUpdate();
                }
                try (Statement stmt = conn.createStatement()) {
                    stmt.execute("UPDATE ChangeRequests SET deployment_id = 0 "
                            + "WHERE deployment_id NOT IN (SELECT id FROM Deployments)");
                }

                String updateSql = "UPDATE Deployments SET name = ?, ritm_number = ?, " +
                        "environment = ?, requested_date = ?, deployed_date = ?, status = ?, " +
                        "requested_by = ?, change_description = ?, tasks_to_deploy = ?, " +
                        "test_log_path = ?, code_analysis_path = ?, code_moved_to_test = ?, " +
                        "notes = ? WHERE id = ?";
                String insertSql = "INSERT INTO Deployments (project_name, name, ritm_number, " +
                        "environment, requested_date, deployed_date, status, requested_by, " +
                        "change_description, tasks_to_deploy, test_log_path, code_analysis_path, " +
                        "code_moved_to_test, notes) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

                try (PreparedStatement update = conn.prepareStatement(updateSql);
                     PreparedStatement insert = conn.prepareStatement(insertSql,
                             Statement.RETURN_GENERATED_KEYS)) {

                    for (Deployment d : deployments) {
                        if (d.id > 0) {
                            update.setString(1, safe(d.name));
                            update.setString(2, safe(d.ritmNumber));
                            update.setString(3, safe(d.environment));
                            update.setString(4, safe(d.requestedDate));
                            update.setString(5, safe(d.deployedDate));
                            update.setString(6, safe(d.status));
                            update.setString(7, safe(d.requestedBy));
                            update.setString(8, safe(d.changeDescription));
                            update.setString(9, safe(d.tasksToDeploy));
                            update.setString(10, safe(d.testLogPath));
                            update.setString(11, safe(d.codeAnalysisPath));
                            update.setString(12, safe(d.codeMovedToTest));
                            update.setString(13, safe(d.notes));
                            update.setInt(14, d.id);
                            update.executeUpdate();
                        } else {
                            bindDeployment(insert, d, projectName);
                            insert.executeUpdate();
                            try (ResultSet keys = insert.getGeneratedKeys()) {
                                if (keys.next()) {
                                    d.id = keys.getInt(1);
                                    d.projectName = projectName;
                                }
                            }
                        }
                    }
                }
                conn.commit();
            } catch (SQLException e) {
                conn.rollback();
                throw e;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // ================= CHANGE REQUESTS =================

    public List<ChangeRequest> getChangeRequests(String projectName) {
        List<ChangeRequest> requests = new ArrayList<>();
        String sql = "SELECT * FROM ChangeRequests WHERE project_name = ? ORDER BY id";
        try (Connection conn = DriverManager.getConnection(DB_URL);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, projectName);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                ChangeRequest cr = new ChangeRequest();
                cr.id = rs.getInt("id");
                cr.projectName = safe(rs.getString("project_name"));
                cr.crNumber = safe(rs.getString("cr_number"));
                cr.title = safe(rs.getString("title"));
                cr.requestedBy = safe(rs.getString("requested_by"));
                cr.receivedDate = safe(rs.getString("received_date"));
                cr.priority = safe(rs.getString("priority"));
                cr.status = safe(rs.getString("status"));
                cr.targetDate = safe(rs.getString("target_date"));
                cr.deliveredDate = safe(rs.getString("delivered_date"));
                cr.deploymentId = rs.getInt("deployment_id");
                cr.notes = safe(rs.getString("notes"));
                requests.add(cr);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return requests;
    }

    /** Nothing references change request ids, so the list is replaced wholesale. */
    public void saveChangeRequests(String projectName, List<ChangeRequest> requests) {
        try (Connection conn = DriverManager.getConnection(DB_URL)) {
            conn.setAutoCommit(false);
            try {
                try (PreparedStatement delete = conn.prepareStatement(
                        "DELETE FROM ChangeRequests WHERE project_name = ?")) {
                    delete.setString(1, projectName);
                    delete.executeUpdate();
                }
                try (PreparedStatement insert = conn.prepareStatement(
                        "INSERT INTO ChangeRequests (project_name, cr_number, title, requested_by, " +
                                "received_date, priority, status, target_date, delivered_date, " +
                                "deployment_id, notes) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)")) {
                    for (ChangeRequest cr : requests) {
                        if (safe(cr.crNumber).isEmpty() && safe(cr.title).isEmpty()) continue;
                        insert.setString(1, projectName);
                        insert.setString(2, safe(cr.crNumber));
                        insert.setString(3, safe(cr.title));
                        insert.setString(4, safe(cr.requestedBy));
                        insert.setString(5, safe(cr.receivedDate));
                        insert.setString(6, safe(cr.priority));
                        insert.setString(7, safe(cr.status));
                        insert.setString(8, safe(cr.targetDate));
                        insert.setString(9, safe(cr.deliveredDate));
                        insert.setInt(10, cr.deploymentId);
                        insert.setString(11, safe(cr.notes));
                        insert.addBatch();
                    }
                    insert.executeBatch();
                }
                conn.commit();
            } catch (SQLException e) {
                conn.rollback();
                throw e;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // ================= APPLICATIONS =================

    /** The master list of applications, in display order. */
    public List<String> getApplications() {
        List<String> applications = new ArrayList<>();
        String sql = "SELECT name FROM Applications ORDER BY sort_order, id";
        try (Connection conn = DriverManager.getConnection(DB_URL);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                applications.add(safe(rs.getString("name")));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return applications;
    }

    /** Appends an application. Returns false when the name already exists. */
    public boolean addApplication(String name) {
        if (name == null || name.trim().isEmpty()) return false;
        String sql = "INSERT OR IGNORE INTO Applications (name, sort_order) VALUES (?, " +
                "(SELECT IFNULL(MAX(sort_order), 0) + 1 FROM Applications))";
        try (Connection conn = DriverManager.getConnection(DB_URL);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, name.trim());
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    /** Removes an application and unlinks it from every project. */
    public void removeApplication(String name) {
        try (Connection conn = DriverManager.getConnection(DB_URL)) {
            try (PreparedStatement pstmt = conn.prepareStatement(
                    "DELETE FROM Applications WHERE name = ?")) {
                pstmt.setString(1, name);
                pstmt.executeUpdate();
            }
            try (PreparedStatement pstmt = conn.prepareStatement(
                    "DELETE FROM ProjectApplications WHERE application_name = ?")) {
                pstmt.setString(1, name);
                pstmt.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /** Applications linked to one project. */
    public List<String> getProjectApplications(String projectName) {
        List<String> applications = new ArrayList<>();
        String sql = "SELECT application_name FROM ProjectApplications " +
                "WHERE project_name = ? ORDER BY application_name COLLATE NOCASE";
        try (Connection conn = DriverManager.getConnection(DB_URL);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, projectName);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                applications.add(safe(rs.getString("application_name")));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return applications;
    }

    /** Replaces a project's application links in one transaction. */
    public void replaceProjectApplications(String projectName, List<String> applications) {
        try (Connection conn = DriverManager.getConnection(DB_URL)) {
            conn.setAutoCommit(false);
            try {
                try (PreparedStatement delete = conn.prepareStatement(
                        "DELETE FROM ProjectApplications WHERE project_name = ?")) {
                    delete.setString(1, projectName);
                    delete.executeUpdate();
                }
                if (applications != null && !applications.isEmpty()) {
                    try (PreparedStatement insert = conn.prepareStatement(
                            "INSERT OR IGNORE INTO ProjectApplications " +
                                    "(project_name, application_name) VALUES (?, ?)")) {
                        for (String application : applications) {
                            insert.setString(1, projectName);
                            insert.setString(2, application);
                            insert.addBatch();
                        }
                        insert.executeBatch();
                    }
                }
                conn.commit();
            } catch (SQLException e) {
                conn.rollback();
                throw e;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Application-to-project pairs for the App Usage report, as
     * {@code {applicationName, projectName}}. Applications nobody uses come
     * back once with an empty project name so they still appear in the report.
     */
    public List<String[]> getApplicationUsage() {
        List<String[]> usage = new ArrayList<>();
        String sql = "SELECT a.name AS application_name, IFNULL(pa.project_name, '') AS project_name " +
                "FROM Applications a " +
                "LEFT JOIN ProjectApplications pa ON pa.application_name = a.name " +
                "ORDER BY a.sort_order, a.id, pa.project_name COLLATE NOCASE";
        try (Connection conn = DriverManager.getConnection(DB_URL);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                usage.add(new String[]{
                        safe(rs.getString("application_name")),
                        safe(rs.getString("project_name"))
                });
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return usage;
    }

    // ================= AUTOMATION ANYWHERE RUN HISTORY =================

    /**
     * Inserts or refreshes scraped activity rows. Existing rows are updated in
     * place, so repeated scrapes of an overlapping window never duplicate.
     *
     * @return the number of rows written
     */
    public int upsertActivities(List<AaActivity> activities) {
        if (activities == null || activities.isEmpty()) return 0;

        String sql = "INSERT INTO AaActivity (id, activity_name, automation_name, automation_type, " +
                "device_name, run_as_user, status, running_time, activity_type, started_on, " +
                "started_display, ended_on, fetched_at) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) " +
                "ON CONFLICT(id) DO UPDATE SET " +
                "activity_name = excluded.activity_name, " +
                "automation_name = excluded.automation_name, " +
                "automation_type = excluded.automation_type, " +
                "device_name = excluded.device_name, " +
                "run_as_user = excluded.run_as_user, " +
                "status = excluded.status, " +
                "running_time = excluded.running_time, " +
                "activity_type = excluded.activity_type, " +
                "started_on = excluded.started_on, " +
                "started_display = excluded.started_display, " +
                "ended_on = excluded.ended_on, " +
                "fetched_at = excluded.fetched_at";

        String fetchedAt = java.time.LocalDateTime.now().toString();
        int written = 0;

        try (Connection conn = DriverManager.getConnection(DB_URL)) {
            conn.setAutoCommit(false);
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                for (AaActivity a : activities) {
                    if (a.id == null || a.id.trim().isEmpty()) continue;
                    pstmt.setString(1, a.id);
                    pstmt.setString(2, safe(a.activityName));
                    pstmt.setString(3, safe(a.automationName));
                    pstmt.setString(4, safe(a.automationType));
                    pstmt.setString(5, safe(a.deviceName));
                    pstmt.setString(6, safe(a.runAsUser));
                    pstmt.setString(7, safe(a.status));
                    pstmt.setString(8, safe(a.runningTime));
                    pstmt.setString(9, safe(a.activityType));
                    pstmt.setString(10, safe(a.startedOn));
                    pstmt.setString(11, safe(a.startedDisplay));
                    pstmt.setString(12, safe(a.endedOn));
                    pstmt.setString(13, fetchedAt);
                    pstmt.addBatch();
                    written++;
                }
                pstmt.executeBatch();
                conn.commit();
            } catch (SQLException e) {
                conn.rollback();
                throw e;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return 0;
        }
        return written;
    }

    /**
     * Activity rows started at or after {@code isoCutoff}, grouped-ready:
     * ordered by device then most recent first. Rows whose start time could not
     * be parsed are always included so nothing silently disappears.
     */
    public List<AaActivity> getActivitiesSince(String isoCutoff) {
        List<AaActivity> activities = new ArrayList<>();
        String sql = "SELECT * FROM AaActivity WHERE started_on >= ? OR started_on = '' " +
                "ORDER BY device_name COLLATE NOCASE, started_on DESC";
        try (Connection conn = DriverManager.getConnection(DB_URL);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, isoCutoff == null ? "" : isoCutoff);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                AaActivity a = new AaActivity();
                a.id = safe(rs.getString("id"));
                a.activityName = safe(rs.getString("activity_name"));
                a.automationName = safe(rs.getString("automation_name"));
                a.automationType = safe(rs.getString("automation_type"));
                a.deviceName = safe(rs.getString("device_name"));
                a.runAsUser = safe(rs.getString("run_as_user"));
                a.status = safe(rs.getString("status"));
                a.runningTime = safe(rs.getString("running_time"));
                a.activityType = safe(rs.getString("activity_type"));
                a.startedOn = safe(rs.getString("started_on"));
                a.startedDisplay = safe(rs.getString("started_display"));
                a.endedOn = safe(rs.getString("ended_on"));
                activities.add(a);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return activities;
    }

    // ================= EXTERNAL BOT DATABASES =================

    /**
     * Turns a configured DB Path into a JDBC URL. A value that already looks
     * like a JDBC URL is passed through untouched, anything else is treated as
     * a SQLite file.
     */
    public static String toJdbcUrl(String dbPath) {
        String path = dbPath == null ? "" : dbPath.trim();
        if (path.toLowerCase().startsWith("jdbc:")) return path;
        return "jdbc:sqlite:" + path;
    }

    /**
     * Runs a query against a project's own database and returns the first
     * column of the first row. Used by the Bot Run Status report, so the query
     * is expected to produce a single value.
     */
    public String queryExternalScalar(String dbPath, String sql) throws SQLException {
        try (Connection conn = DriverManager.getConnection(toJdbcUrl(dbPath));
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next()) {
                Object value = rs.getObject(1);
                return value == null ? "" : value.toString();
            }
        }
        return "";
    }

    private static String safe(String value) {
        return value == null ? "" : value;
    }

    // ================= APPLICATION SETTINGS =================

    /** Reads a persisted preference, falling back to {@code defaultValue}. */
    public String getSetting(String key, String defaultValue) {
        String sql = "SELECT value FROM Settings WHERE key = ?";
        try (Connection conn = DriverManager.getConnection(DB_URL);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, key);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                String value = rs.getString("value");
                if (value != null) return value;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return defaultValue;
    }

    /** Stores a preference, overwriting any previous value. */
    public void setSetting(String key, String value) {
        String sql = "INSERT INTO Settings (key, value) VALUES (?, ?) " +
                "ON CONFLICT(key) DO UPDATE SET value = ?";
        try (Connection conn = DriverManager.getConnection(DB_URL);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, key);
            pstmt.setString(2, value);
            pstmt.setString(3, value);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}